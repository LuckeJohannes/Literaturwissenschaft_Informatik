# Korpus29
# ========

# rm(list = ls())
# Strg + l

library(stylo)

basisPfad <- "c:/R_workdir/"
istPfad <- "Korpus29"
sollPfad <- paste0(basisPfad, istPfad)
#setwd(sollPfad)
#getwd()

#source("generalFunctions.R")

path_results <- paste0(sollPfad, "/", "results")
path_corpus <- paste0(sollPfad, "/", "corpus")
setwd(path_results)

MFW <- 500
distance_measure <- "dist.delta"


#------------------------------------------------------------------------------#
## Stilometrische Analyse -----------------------------------------------------#
#------------------------------------------------------------------------------#

# falls eigene wordlist, dann wordlist.txt in results

batch <- stylo(gui = FALSE,
               corpus = path_corpus,
               distance.measure = distance_measure,
               corpus.format = "plain",
               corpus.lang = "German",
               analyzed.features = "w",
               ngram.size = 1,
		use.existing.wordlist = FALSE,
               preserve.case = FALSE,
               encoding = "UTF-8",
               mfw.min = MFW,
               mfw.max = MFW,
               mfw.incr = 0,
               culling.min = 0,
               culling.max = 0,
               culling.incr = 0,
               analysis.type = "CA",
               write.pdf.file = TRUE,
               write.jpg.file = FALSE,
               write.svg.file = TRUE,
               save.distance.tables = TRUE,
               save.analyzed.features = TRUE,
               save.analyzed.freqs = TRUE,
               display.on.screen = TRUE)

# assigning plot colors according to file names
# assign.plot.colors(sample.names, col = "greyscale")

batch_zscores <- batch$table.with.all.zscores
all.zs <- t(batch_zscores)
if (ncol(batch_zscores) >= MFW){
  zs <- batch_zscores[,1:MFW]
} else {
  zs <- batch_zscores
}

corpus <- istPfad
filename_zscore <- paste0(corpus, "_", MFW, "MFW", "_zscores.csv")
write.csv(zs, file = filename_zscore)

