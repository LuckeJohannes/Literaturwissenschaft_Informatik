Clusterung mit R, KI
====================

Autorendaten
Autor	Epoche	Berühmtheitsgrad	Anzahl Texte	Gattung	Geschlecht

Alles in c:\AutorenCluster entpacken


R-Skript
--------

# install.packages('factoextra')
library(factoextra)

# install.packages('cluster')
library(cluster)

setwd("c:\\AutorenCluster")	
df = read.csv("Autorendaten.csv", header = TRUE, sep = " ", dec = ",")	# 5 Attr
# df = read.csv("Autorendaten4.csv", header = TRUE, sep = ";", dec = ",")		# 4 Attr
df <- na.omit(df)
df <- scale(df)

fviz_nbclust(df, kmeans, method = "wss")	# Bei Ellenbogen ist opt. Anz. Cluster
gap_stat <- clusGap(df,
                    FUN = kmeans,
                    nstart = 25,
                    K.max = 10,
                    B = 50)
fviz_gap_stat(gap_stat)				# Lückenstatistik; bei Max ist opt. Anz Cluster

set.seed(1)	# make this example reproducible
km <- kmeans(df, centers = 4, nstart = 25)	# center = 4 --> 4 Cluster
km
fviz_cluster(km, data = df)

# aggregate(df[,2:6], by=list(cluster=km$cluster), mean)
aggregate(df, by=list(cluster=km$cluster), mean)

# final_data <- cbind(df[,1:6], cluster = km$cluster)
final_data <- cbind(df, cluster = km$cluster)
final_data

#----------------------------------------------------------------------------------------

# mit Autorendaten.csv, nur 4 Attr. 

set.seed(1)	# make this example reproducible
km <- kmeans(df[,c(1,2,3,4)], centers = 4, nstart = 25)	# center = 4 --> 4 Cluster
km
fviz_cluster(km, data = df)


# mit Autorendaten4.csv, nur 4 Attr. 

df = read.csv("Autorendaten4.csv", header = TRUE, sep = ";", dec = ",")	# 5 Attr
df <- na.omit(df)
df <- scale(df)

set.seed(1)	# make this example reproducible
km <- kmeans(df, centers = 4, nstart = 25)	# center = 4 --> 4 Cluster
km
fviz_cluster(km, data = df)


#******************************************************************************************
#******************************************************************************************

Skript mit Details
------------------

Der folgende Code zeigt, wie Sie Folgendes tun:
    Laden Sie den Autoren- Datensatz
    Entfernen Sie alle Zeilen mit fehlenden Werten
    Skalieren Sie jede Variable im Datensatz auf einen Mittelwert von 0 und eine Standardabweichung von 1

# In csv stehen in der Kopfzeile nur die Attribute (nicht mehr der Autorname), ab Zeile 2 hat jeder Datensatz in der 1. Spalte den Autorenanmen
# Dann wird der Autorname zum Index und scale hat kein Problem mehr mit nicht-numerischen Daten

#also csv Zeile 1 und 2
#"Epoche" "Berühmtheitsgrad" "AnzahlWerke" "Gattung" "Geschlecht"
#"GBenn" 9 2 50 3 1

#********************* Script *******************************

# ggfs. rm(list = ls()) und Strg + l 

# install.packages('factoextra')
library(factoextra)

# install.packages('cluster')
library(cluster)

# df <- Autoren
setwd("c:\\AutorenCluster")
# read.csv(file, header = TRUE, sep = ";", dec = ",")

# 5 Attr
df = read.csv("Autorendaten.csv", header = TRUE, sep = " ", dec = ",")

# 4 Attr
# df = read.csv("Autorendaten4.csv", header = TRUE, sep = ";", dec = ",")

# Zeilen mit fehlenden Werten entfernen</strong>
df <- na.omit(df)

#skalieren Sie jede Variable auf einen Mittelwert von 0 und einer Standardabweichung von 1

# Welche Reduktionen werden durch mathematische Operationen vorgenommen, wie z.B. bei der K-means # Clusterung mit dem System R 
# (Skalierung der Variablen auf einen Mittelwert von 0 mit Subtraktion des # Mittelwerts und auf eine Standardabweichung von 1 mit Division durch die Standardabweichung)

df <- scale(df) # falls 1. Spalte kein Index sondern Daten ---> Fehler x must be num. wg. 1. Spalte

# Die ersten sechs Zeilen des Datensatzes anzeigen
head(df)

#Da wir vorher nicht wissen, wie viele Cluster optimal sind, erstellen wir zwei verschiedene Diagramme, die uns bei der Entscheidung helfen können:

# 1. Anzahl der Cluster im Vergleich zur Summe innerhalb der Quadratsumme

#Zuerst verwenden wir die Funktion fviz_nbclust(), um ein Diagramm der Anzahl der Cluster gegen die Summe innerhalb der Summe der Quadrate zu erstellen:
fviz_nbclust(df, kmeans, method = "wss")

#Wenn wir diese Art von Plot erstellen, suchen wir normalerweise nach einem „Ellenbogen“, bei dem sich die Summe der Quadrate zu „biegen“ oder zu glätten beginnt. 
#Dies ist normalerweise die optimale Anzahl von Clustern.

#Für dieses Diagramm gibt es bei k = 4 Clustern einen kleinen Ellbogen oder eine „Biegung“.

# 2. Anzahl der Cluster vs. Lückenstatistik

#Eine andere Möglichkeit, die optimale Anzahl von Clustern zu bestimmen, besteht darin, eine als Gap-Statistik bekannte Metrik zu verwenden, die die gesamte #Variation innerhalb des Clusters für verschiedene Werte von k mit ihren erwarteten Werten für eine Verteilung ohne Clustering vergleicht.

#Wir können die Lückenstatistik für jede Anzahl von Clustern mithilfe der Funktion clusGap() aus dem Clusterpaket zusammen mit einer Darstellung der #Clusterstatistik gegen die Lückenstatistik mithilfe der Funktion fviz_gap_stat() berechnen:

#Berechnen Sie die Lückenstatistik basierend auf der Anzahl der Cluster
gap_stat <- clusGap(df,
                    FUN = kmeans,
                    nstart = 25,
                    K.max = 10,
                    B = 50)

#Plotten der Anzahl der Cluster vs. Lückenstatistik
fviz_gap_stat(gap_stat)

#Lückenstatistik für optimale Anzahl von Clustern

#Aus dem Diagramm können wir ersehen, dass die Lückenstatistik bei k = 4 Clustern am höchsten ist, 
#was der zuvor verwendeten Ellbogenmethode entspricht.

# Nun die Clusterung
# Um k-Means Clustering in R durchzuführen, können wir die integrierte Funktion kmeans() verwenden, die die folgende Syntax verwendet:
#    kmeans(data, centers, nstart)
#wobei:
#    data: Name des Datensatzes.
#    centers: Die Anzahl der Cluster, bezeichnet mit k.
#    nstart: Die Anzahl der Erstkonfigurationen. 
#	Da es möglich ist, dass unterschiedliche anfängliche Startcluster zu unterschiedlichen Ergebnissen führen können, 
#	wird empfohlen, mehrere unterschiedliche anfängliche Konfigurationen zu verwenden. 
#	Der k-means-Algorithmus findet die Anfangskonfigurationen, die zur kleinsten Variation innerhalb des Clusters führen.

# make this example reproducible
set.seed(1)
km <- kmeans(df, centers = 4, nstart = 25)
km

fviz_cluster(km, data = df)

# aggregate(df[,2:6], by=list(cluster=km$cluster), mean)
aggregate(df, by=list(cluster=km$cluster), mean)

# final_data <- cbind(df[,1:6], cluster = km$cluster)
final_data <- cbind(df, cluster = km$cluster)
final_data
